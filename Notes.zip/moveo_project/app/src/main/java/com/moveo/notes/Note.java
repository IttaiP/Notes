package com.moveo.notes;

public class Note {
    String title;
    String body;
    Date date;

    public Note(String title,String body,Date date){

    }
}
