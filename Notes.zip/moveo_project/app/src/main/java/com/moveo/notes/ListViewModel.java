package com.moveo.notes;

import androidx.lifecycle.ViewModel;

public class ListViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}